// src/pages/job.tsx
/*import { ContactSection } from '@/components/ContactSection';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { deleteContact, postContact, updateContact } from '@/services/contact/contact';
import React, { useState, useEffect } from 'react';

const Contact = () => {
  const [contactData, setContactData] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
    const { isAuthenticated } = useAuth();


  useEffect(() => {
    // Fetch job data if updating (Replace with actual job id)
    if (isEditing && contactData) {
      setContactData(contactData);
    }
  }, [isEditing, contactData]);

  const handlePostContact = async (contact: any) => {
    try {
      const newContact = await postContact(contact);
      alert('Contact posted successfully');
      console.log(newContact);
    } catch (error) {
      alert('Error posting contact');
    }
  };

  const handleUpdateContact = async (contact: any) => {
    try {
      const updatedContact = await updateContact(contactData.id, contact);
      alert('Contact updated successfully');
      console.log(updatedContact);
    } catch (error) {
      alert('Error updating contact');
    }
  };

  const handleDeleteJob = async () => {
    if (window.confirm('Are you sure you want to delete this contact?')) {
      try {
        await deleteContact(contactData.id);
        alert('Contact deleted successfully');
        setContactData(null); // Reset contact data after delete
      } catch (error) {
        alert('Error deleting contact');
      }
    }
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Job Management</h1>
      {!contactData ? (
        <ContactSection contactData={null} onSubmit={handlePostContact} />
      ) : (
        <>
          <ContactSection contactId={contactData.id} jobData={contactData} onSubmit={handleUpdateContact} />
          <Button onClick={handleDeleteJob} className="mt-4 bg-red-600 text-white">
            Delete Job
          </Button>
        </>
      )}
    </div>
  );
};

export default Contact;
*/